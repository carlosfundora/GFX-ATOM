import numpy as np
import rs_codec
import time

x = np.random.randn(24000).astype(np.float32)
start = time.time()
y, gain = rs_codec.soft_compressor(x, 0.5, 4.0, 0.01, 0.1, 1.0)
print("Soft compressor:", time.time() - start)

start = time.time()
z, gain2 = rs_codec.agc_kernel(y, 0.125, 0.01, 0.1, 10.0, 2400, 1.0)
print("AGC:", time.time() - start)
